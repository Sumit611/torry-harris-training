package com.torryharris.model;

public interface Car extends Vehicle{
    void changeGear();
}
