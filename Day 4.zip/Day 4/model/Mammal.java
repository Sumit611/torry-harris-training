package com.torryharris.model;

public interface Mammal extends Animal{
    void feed();
}
