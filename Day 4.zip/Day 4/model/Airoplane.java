package com.torryharris.model;

public interface Airoplane extends Vehicle{
    void fly();
}
