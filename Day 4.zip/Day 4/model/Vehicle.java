package com.torryharris.model;

public interface Vehicle {
    void move();
}
