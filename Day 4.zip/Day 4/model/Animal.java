package com.torryharris.model;

public interface Animal {
    void eat();
}
